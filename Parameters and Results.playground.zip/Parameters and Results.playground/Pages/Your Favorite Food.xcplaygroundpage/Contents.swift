/*:
## Your Favorite Food
 
 The following code prints the value of a constant to the console:

```
 let favoriteFood = "cheese"
 print("My favorite food is " + favoriteFood)
```

 - callout(Exercise): Put the print statement above inside a function that allows you to pass in any string as an argument. When you call the function, it should look like this:\
 `printFavorite(food: "cheese")`\
 _Hint: You can go back to the previous page to check on how to define a function with a parameter._
 */
let favoriteFood = "Cheese!"
func favFood(food: String) {
    print("My favorite food is " + food)
}
favFood(food: favoriteFood)
/*:
Wouldn’t it be useful to pass in more than one value? Find out how.

[Previous](@previous)  |  page 3 of 18  |  [Next: Passing More Values](@next)
 */
