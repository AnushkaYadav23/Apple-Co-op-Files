/*:
## Exercise: Go! Fight! Win!
 
 Many schools have “fight songs.” Students learn at least some portion of the words and sing the songs loudly at school sports events.

 You’ve decided that your school’s fight song needs a rewrite. You want to edit the song in code so you don’t have to copy and paste as much while you work.
 
 1. Edit the `song` to have more than a repeated refrain.
 2. Edit the `refrain` to have actual words.
 3. Edit the `refrain` to use the `schoolName` at least twice.
 4. Test your work by changing the school name to a fictional school.
 
 Use string interpolation in case you decide to sell your brilliant song to another school.

 - Note: 
 Use the show result button to view the results of your work.
 */
let schoolName = "MEADOWVALE"
let schoolName2 = "MDV!"
let refrain = "Let's go \(schoolName) Let's go! \(schoolName2)"

let song = "Yeah! \(refrain)\n\(refrain)\nYes, \(refrain)"

/*:
[Previous](@previous)  |  page 16 of 18  |  [Next: Exercise: Displaying Values](@next)
 */
