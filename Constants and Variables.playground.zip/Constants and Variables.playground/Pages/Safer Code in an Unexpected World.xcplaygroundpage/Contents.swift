/*:
## Safer Code in an Unexpected World

 Changing the value of something should only be done deliberately. When writing a program, it should be clear what each piece of code is expected to do. If you make everything a variable, you or someone else might change a value, whether accidentally or on purpose. In any case, the change can cause a problem somewhere down the line.

 Consider this program for recording and calculating scores in a game:
 */
// Scores for each target
let scoreForGreen = 5
let scoreForRed = 10
let scoreForGold = 20

// Player scores
var scoreForGary = 0
var scoreForRob = 0

// Game events here
scoreForGary += scoreForRed
scoreForGary += scoreForGreen
scoreForGary += scoreForGold

scoreForRob += scoreForRed
scoreForRob += scoreForGreen
scoreForRob += scoreForGold

scoreForGary += scoreForRed
scoreForGary += scoreForGreen
scoreForGary += scoreForGold

scoreForRob += scoreForRed
scoreForRob += scoreForGreen
scoreForRob += scoreForGold

scoreForRob
scoreForGary
/*:
 - callout(Exercise): The program above has a problem. Each player hit the same targets, but Rob has fewer points than Gary at the end of the game. Can you find the problem?\
 _Hint: At the start of the program, try defining the target scores with `let` instead of `var`._
 */
 



/*:
[Previous](@previous)  |  page 10 of 13  |  [Next: Wrapping Up](@next)
 */
